package Simulacro_Tema_3;
import java.util.*;
public class Ejercicio_1 {
	private static Scanner teclado = new Scanner(System.in);//Arranco el escaner para que luego lea lo introducido por el teclado
	public static void main(String[] args) {// Método principal, punto de entrada del programa
		boolean otraOpcion=true;
		String frase=pedirFrase();
		menuOpciones();
		int contarLetras=contarLetras(frase);
		int contarPalabras=contarPalabras(frase);
		String mayusculas=mayusculas(frase);
		String inversa=inversa(frase);
		opcionSeleccionada(contarLetras,contarPalabras, mayusculas, inversa);
		if(otraOpcion==true) {
			menuOpciones();
			opcionSeleccionada(contarLetras,contarPalabras, mayusculas, inversa);
			otraOpcion=repeticion();
		}
	}
	
	private static String pedirFrase() {
        System.out.println("Ingrese una frase o palabra");
        String frase = teclado.nextLine().toLowerCase();
        return frase;
    }
	
	private static void menuOpciones() {
		System.out.println("Menu:");
		System.out.println("1. Contar letras");
		System.out.println("2. Contar palabras");
		System.out.println("3. Mayusculas");
		System.out.println("4. Invertir");
		System.out.println("5. Salir del menu");
	}
	
	
	
	private static void opcionSeleccionada(int contarLetras, int contarPalabras, String mayusculas, String inversa) {
		System.out.println("Ingrese una opcion");
		int opcion = teclado.nextInt();
		switch (opcion){
			case 1:
				System.out.println("El numero de letras es: " + contarLetras);
				break;
			case 2:
				System.out.println("El nuemero de palabras es: " + contarPalabras);
				break;
			case 3:
				System.out.println("La frase con las primeras letras de cada palabra en mayusculas es: " + mayusculas);
				break;
			case 4:
				System.out.println("La frase invertida es: " + inversa);
				break;
			case 5:
				break;
			default:
				System.out.println("El numero no entra dentro de las opciones intentelo de nuevo");
				opcionSeleccionada(contarLetras,contarPalabras, mayusculas, inversa);
		}
	}
	
	private static int contarLetras(String frase) {
		int numLetras=0;
		for(int i=0; i<=frase.length(); i++) {
			if(Character.isLetter(frase.charAt(i))) {
				numLetras++;
			}
		}return numLetras;
	}
	
	private static int contarPalabras(String frase) {
		int numPalabras=0;
		for(int i=0; i<frase.length(); i++) {
			if(Character.isLetter(i)==true && frase.charAt(i-1)==' ') {
				numPalabras++;
			}
		}return numPalabras;
	}
	
	private static String mayusculas(String frase) {
		String mayusculas="";
		for(int i=0; i<frase.length(); i++) {
			if(Character.isLetter(i)==true && frase.charAt(i-1)==' ') {
				frase.toUpperCase().charAt(i);
			}
		}
		return mayusculas;
	}
	
	private static String inversa(String frase) {
		String inversa="";
		for(int i=0; i<frase.length(); i++) {
			
		}
		return inversa;
	}
	
	private static boolean repeticion() {
		boolean repeticion=true;
		System.out.println("¿Desea hacer alguna otra operacion?(true/false)");
		repeticion= teclado.nextBoolean();
		while(repeticion!=true || repeticion!=false) {
			System.out.println("Debes responder con true o false");
			repeticion= teclado.nextBoolean();
		}
		return repeticion;
	}
}
